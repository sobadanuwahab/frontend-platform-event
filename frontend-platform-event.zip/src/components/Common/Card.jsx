import React from "react";

function Card() {
  return <div>Card</div>;
}

export default Card;
