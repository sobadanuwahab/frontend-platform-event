import React from "react";

const TicketsTab = () => {
  return <div>TicketsTab</div>;
};

export default TicketsTab;
