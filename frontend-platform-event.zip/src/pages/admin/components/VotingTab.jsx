import React from "react";

const VotingTab = () => {
  return <div>VotingTab</div>;
};

export default VotingTab;
