import React from "react";

const HistoryTab = () => {
  return <div>HistoryTab</div>;
};

export default HistoryTab;
