import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Save,
  X,
  AlertCircle,
  CheckCircle,
  ArrowLeft,
  Loader,
  Image as ImageIcon,
  Trash2,
  Eye,
  Bug,
  User,
  Info,
} from "lucide-react";
import api from "../../../../services/api";
import { useAuth } from "../../../../context/AuthContext";

const EditEvent = () => {
  const { id } = useParams(); // event_id
  const navigate = useNavigate();
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const [eventData, setEventData] = useState(null);

  const [formData, setFormData] = useState({
    name: "",
    organized_by: "",
    location: "",
    event_info: "",
    term_condition: "",
    start_date: "",
    end_date: "",
    image: null,
  });

  const [imagePreview, setImagePreview] = useState("");
  const [originalImage, setOriginalImage] = useState("");

  const toDateInputValue = (date) => {
    if (!date) return "";
    return date.split(" ")[0]; // buang jam
  };

  /* ================= LOAD EVENT ================= */
  useEffect(() => {
    if (!id || !user) return;

    const loadEvent = async () => {
      try {
        const res = await api.get("/list-event-by-user");

        if (!Array.isArray(res.data?.data)) {
          throw new Error("Data event tidak valid");
        }

        const event = res.data.data.find((e) => Number(e.id) === Number(id));

        if (!event) {
          throw new Error("EVENT_NOT_OWNED");
        }

        setEventData(event);

        setFormData({
          name: event.name ?? "",
          organized_by: event.organized_by ?? "",
          location: event.location ?? "",
          event_info: event.event_info ?? "",
          term_condition: event.term_condition ?? "",
          start_date: toDateInputValue(event.start_date),
          end_date: toDateInputValue(event.end_date),
          image: null,
        });

        // console.log("EVENT RAW FROM API:", event);

        if (event.image) {
          const imgUrl = `https://apipaskibra.my.id/storage/${event.image}`;
          setImagePreview(imgUrl);
          setOriginalImage(imgUrl);
        }
      } catch (err) {
        navigate("/organizer/events", { replace: true });
      } finally {
        setLoading(false);
      }
    };

    loadEvent();
  }, [id, user]);

  /* ================= IMAGE ================= */
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setError("Ukuran gambar maksimal 5MB");
      return;
    }

    setFormData((p) => ({ ...p, image: file }));
    setImagePreview(URL.createObjectURL(file));
  };

  const removeImage = () => {
    setFormData((p) => ({ ...p, image: null }));
    setImagePreview(originalImage);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  /* ================= SUBMIT ================= */
  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError("");

    try {
      const data = new FormData();
      data.append("event_id", id);
      data.append("user_id", user.id);
      data.append("name", formData.name);
      data.append("organized_by", formData.organized_by);
      data.append("location", formData.location);
      data.append("event_info", formData.event_info);
      data.append("term_condition", formData.term_condition);
      data.append("start_date", formData.start_date);
      data.append("end_date", formData.end_date);
      data.append("_method", "PUT");

      if (formData.image) {
        data.append("image", formData.image);
      }

      await api.post(`/edit-event/${id}`, data, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      setSuccess(true);
      setTimeout(() => navigate("/organizer/events"), 1200);
    } catch (err) {
      setError(err.message || "Gagal update event");
    } finally {
      setSubmitting(false);
    }
  };

  /* ================= DELETE ================= */
  const handleDeleteEvent = async () => {
    if (!window.confirm("Hapus event ini?")) return;
    await api.delete(`/delete-event/${id}`);
    navigate("/organizer/events");
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader className="animate-spin h-10 w-10 text-blue-500" />
      </div>
    );
  }

  if (!eventData) {
    return (
      <div className="max-w-4xl mx-auto text-center p-8">
        <AlertCircle className="h-16 w-16 text-red-400 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-white mb-2">
          Event Tidak Ditemukan
        </h2>
        <p className="text-gray-400 mb-6">
          Event dengan ID {id} tidak ditemukan atau Anda tidak memiliki akses.
        </p>
        <button
          onClick={() => navigate("/organizer/events")}
          className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600"
        >
          Kembali ke Daftar Event
        </button>
      </div>
    );
  }

  /* ================= RENDER FORM ================= */
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto"
    >
      {/* Header */}
      <div className="mb-8">
        <button
          onClick={() => navigate("/organizer/events")}
          className="flex items-center space-x-2 text-gray-400 hover:text-white mb-6"
        >
          <ArrowLeft size={20} />
          <span>Kembali ke Daftar Event</span>
        </button>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold mb-2">Edit Event</h1>
            <p className="text-gray-400">
              Edit detail event "{eventData?.name}"
            </p>
            {user && (
              <div className="mt-2 text-sm text-gray-500">
                <div className="flex items-center gap-2">
                  <span>
                    Editor: <span className="text-blue-400">{user.name}</span>
                  </span>
                  <span className="text-gray-600">•</span>
                  <span>
                    ID: <span className="text-blue-400">{user.id}</span>
                  </span>
                  <span className="text-gray-600">•</span>
                  <span>
                    Event ID: <span className="text-blue-400">{id}</span>
                  </span>
                </div>
              </div>
            )}
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => navigate(`/organizer/events/${id}`)}
              className="px-4 py-2 rounded-xl bg-gray-800 hover:bg-gray-700 border border-gray-700 transition-colors font-medium flex items-center gap-2"
            >
              <Eye size={16} />
              Lihat Detail
            </button>
            <button
              onClick={handleChange}
              className="px-4 py-2 rounded-xl bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 text-red-400 transition-colors font-medium flex items-center gap-2"
            >
              <Trash2 size={16} />
              Hapus
            </button>
          </div>
        </div>
      </div>

      {/* Form */}
      <div className="bg-gray-800/50 rounded-2xl border border-gray-700 p-6">
        {/* Error Alert */}
        {error && !success && (
          <div className="mb-6 p-4 rounded-xl bg-red-500/10 border border-red-500/30">
            <div className="flex items-start space-x-3">
              <AlertCircle
                size={20}
                className="text-red-400 flex-shrink-0 mt-0.5"
              />
              <div>
                <p className="text-red-400 font-medium">
                  Gagal mengupdate event
                </p>
                <p className="text-red-300 text-sm mt-1 whitespace-pre-line">
                  {error}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Success Alert */}
        {success && (
          <div className="mb-6 p-4 rounded-xl bg-green-500/10 border border-green-500/30">
            <div className="flex items-start space-x-3">
              <CheckCircle
                size={20}
                className="text-green-400 flex-shrink-0 mt-0.5"
              />
              <div>
                <p className="text-green-400 font-medium">Berhasil!</p>
                <p className="text-green-300 text-sm mt-1">
                  Event berhasil diupdate. Mengarahkan ke halaman event...
                </p>
              </div>
            </div>
          </div>
        )}

        {/* User Information */}
        <div className="mb-8 p-4 rounded-xl bg-gray-900/50 border border-gray-700">
          <h3 className="text-lg font-bold mb-3 text-gray-300 flex items-center gap-2">
            <User size={20} />
            Informasi Editor
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-400 mb-1">Nama Editor</p>
              <p className="text-gray-300 font-medium">{user?.name || "-"}</p>
            </div>
            <div>
              <p className="text-sm text-gray-400 mb-1">User ID</p>
              <p className="text-blue-400 font-mono font-medium">
                {user?.id || "-"}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-400 mb-1">Event ID</p>
              <p className="text-yellow-400 font-mono font-medium">{id}</p>
            </div>
            <div>
              <p className="text-sm text-gray-400 mb-1">Event Name</p>
              <p className="text-gray-300 font-medium">
                {eventData?.name || "-"}
              </p>
            </div>
          </div>

          {/* Image Debug Info */}
          {eventData && (
            <div className="mt-4 p-3 bg-blue-500/10 rounded-lg">
              <p className="text-xs text-blue-300 mb-1">
                <strong>Image Info:</strong>
              </p>
              <p className="text-xs text-gray-400">
                {imagePreview && imagePreview.startsWith("http")
                  ? `Image URL: ${imagePreview.substring(0, 60)}...`
                  : "No image found in event data"}
              </p>
              {eventData.image && (
                <p className="text-xs text-gray-400 mt-1">
                  Image path in data: {eventData.image}
                </p>
              )}
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Basic Information */}
          <div>
            <h3 className="text-lg font-bold mb-4 text-gray-300 border-b border-gray-700 pb-2">
              Informasi Dasar Event
            </h3>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Nama Event *
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  disabled={submitting}
                  className="w-full px-4 py-3 rounded-xl bg-gray-900 border border-gray-700 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
                  placeholder="Nama event"
                  maxLength={200}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Diselenggarakan Oleh *
                </label>
                <input
                  type="text"
                  name="organized_by"
                  value={formData.organized_by}
                  onChange={handleChange}
                  required
                  disabled={submitting}
                  className="w-full px-4 py-3 rounded-xl bg-gray-900 border border-gray-700 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
                  placeholder="Penyelenggara"
                  maxLength={200}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Lokasi *
                </label>
                <textarea
                  name="location"
                  value={formData.location}
                  onChange={handleChange}
                  required
                  disabled={submitting}
                  rows="3"
                  className="w-full px-4 py-3 rounded-xl bg-gray-900 border border-gray-700 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none disabled:opacity-50"
                  placeholder="Lokasi event"
                  maxLength={500}
                />
              </div>
            </div>
          </div>

          {/* Date Information */}
          <div>
            <h3 className="text-lg font-bold mb-4 text-gray-300 border-b border-gray-700 pb-2">
              Waktu Pelaksanaan
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Tanggal Mulai *
                </label>
                <input
                  type="date"
                  name="start_date"
                  value={formData.start_date}
                  onChange={handleChange}
                  required
                  disabled={submitting}
                  className="w-full px-4 py-3 rounded-xl bg-gray-900 border border-gray-700 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Tanggal Selesai *
                </label>
                <input
                  type="date"
                  name="end_date"
                  value={formData.end_date}
                  onChange={handleChange}
                  required
                  disabled={submitting}
                  min={formData.start_date}
                  className="w-full px-4 py-3 rounded-xl bg-gray-900 border border-gray-700 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
                />
              </div>
            </div>
          </div>

          {/* Event Information */}
          <div>
            <h3 className="text-lg font-bold mb-4 text-gray-300 border-b border-gray-700 pb-2">
              Informasi Event
            </h3>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Deskripsi Event
                </label>
                <textarea
                  name="event_info"
                  value={formData.event_info}
                  onChange={handleChange}
                  disabled={submitting}
                  rows="4"
                  className="w-full px-4 py-3 rounded-xl bg-gray-900 border border-gray-700 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none disabled:opacity-50"
                  placeholder="Deskripsi event"
                  maxLength={2000}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Syarat & Ketentuan
                </label>
                <textarea
                  name="term_condition"
                  value={formData.term_condition}
                  onChange={handleChange}
                  disabled={submitting}
                  rows="4"
                  className="w-full px-4 py-3 rounded-xl bg-gray-900 border border-gray-700 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none disabled:opacity-50"
                  placeholder="Syarat dan ketentuan"
                  maxLength={2000}
                />
              </div>
            </div>
          </div>

          {/* Image Upload Section */}
          <div>
            <h3 className="text-lg font-bold mb-4 text-gray-300 border-b border-gray-700 pb-2">
              Poster Event
            </h3>
            <div className="space-y-4">
              <div className="text-sm text-gray-400 mb-2">
                <p>Format: JPG, JPEG, PNG, GIF, WebP (max. 5MB)</p>
                <p className="text-yellow-400">
                  Kosongkan jika tidak ingin mengganti gambar
                </p>
              </div>

              <input
                type="file"
                accept="image/jpeg,image/jpg,image/png,image/gif,image/webp"
                onChange={handleImageChange}
                className="hidden"
                id="event-image-upload"
                disabled={submitting}
              />

              <div className="flex flex-col md:flex-row gap-6">
                {/* Upload Area */}
                <label
                  htmlFor="event-image-upload"
                  className={`flex-1 cursor-pointer ${submitting ? "opacity-50 cursor-not-allowed" : ""}`}
                >
                  <div className="border-2 border-dashed border-gray-700 rounded-2xl p-8 text-center hover:border-blue-500 transition-colors h-full">
                    <div className="flex flex-col items-center space-y-4">
                      <ImageIcon size={32} className="text-gray-400" />
                      <div>
                        <p className="text-gray-300 font-medium">
                          {formData.image
                            ? "Ganti Gambar"
                            : imagePreview && !imagePreview.startsWith("data:")
                              ? "Ganti Gambar"
                              : "Upload Poster"}
                        </p>
                        <p className="text-sm text-gray-500">
                          PNG, JPG, JPEG, GIF, WebP
                        </p>
                        {formData.image ? (
                          <p className="text-xs text-green-400 mt-1">
                            ✓ Gambar baru dipilih
                          </p>
                        ) : imagePreview &&
                          !imagePreview.startsWith("data:") ? (
                          <p className="text-xs text-yellow-400 mt-1">
                            ✓ Gambar saat ini dari server
                          </p>
                        ) : null}
                      </div>
                    </div>
                  </div>
                </label>

                {/* Preview Area */}
                <div className="flex-1">
                  <div className="rounded-2xl border border-gray-700 p-4 h-full">
                    <div className="flex items-center justify-between mb-3">
                      <p className="text-sm text-gray-400">Preview:</p>
                      {imagePreview && !imagePreview.startsWith("data:") && (
                        <span className="text-xs px-2 py-1 bg-blue-500/20 text-blue-400 rounded">
                          Gambar Server
                        </span>
                      )}
                    </div>

                    {imagePreview ? (
                      <div className="space-y-4">
                        <div className="relative aspect-video rounded-xl overflow-hidden bg-gray-900 border border-gray-700">
                          <img
                            src={imagePreview}
                            alt="Event Preview"
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              console.error(
                                "❌ Error loading preview:",
                                imagePreview,
                              );
                              addDebugLog(
                                `❌ Failed to load image: ${imagePreview}`,
                              );

                              // Fallback ke placeholder jika gambar gagal load
                              e.target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(formData.name || "Event")}&background=1e40af&color=fff&size=400`;
                              e.target.className =
                                "w-full h-full object-contain p-8";
                            }}
                          />

                          {/* Image change indicator */}
                          {formData.image && (
                            <div className="absolute top-2 left-2 bg-green-500 text-white text-xs px-2 py-1 rounded">
                              Gambar Baru
                            </div>
                          )}

                          {/* Remove button */}
                          {formData.image && (
                            <button
                              type="button"
                              onClick={removeImage}
                              disabled={submitting}
                              className="absolute top-2 right-2 p-2 rounded-lg bg-red-500/80 hover:bg-red-600 text-white disabled:opacity-50"
                              title="Hapus gambar baru"
                            >
                              <X size={16} />
                            </button>
                          )}
                        </div>

                        {/* Image Info */}
                        <div className="space-y-2">
                          {formData.image ? (
                            <>
                              <p className="text-xs text-gray-400 text-center">
                                <span className="text-green-400">
                                  Gambar baru:
                                </span>{" "}
                                {formData.image.name}
                              </p>
                              <p className="text-xs text-gray-400 text-center">
                                Ukuran:{" "}
                                {(formData.image.size / 1024 / 1024).toFixed(2)}{" "}
                                MB
                              </p>
                            </>
                          ) : imagePreview &&
                            !imagePreview.startsWith("data:") ? (
                            <>
                              <p className="text-xs text-gray-400 text-center">
                                <span className="text-yellow-400">
                                  Gambar saat ini:
                                </span>{" "}
                                {eventData?.image || "Dari server"}
                              </p>
                              <div className="flex items-center justify-center gap-2">
                                <a
                                  href={imagePreview}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-xs text-blue-400 hover:text-blue-300 underline"
                                >
                                  Lihat gambar asli
                                </a>
                              </div>
                            </>
                          ) : null}
                        </div>
                      </div>
                    ) : (
                      <div className="aspect-video rounded-xl bg-gray-900/50 border border-dashed border-gray-700 flex flex-col items-center justify-center">
                        <ImageIcon size={48} className="text-gray-600 mb-2" />
                        <p className="text-sm text-gray-500">
                          Tidak ada gambar
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Event Data Debug Info */}
              {eventData && (
                <div className="mt-4 p-3 bg-gray-900/30 rounded-lg">
                  <p className="text-xs text-gray-400 mb-2">
                    <strong>Event Data Debug:</strong>
                  </p>
                  <div className="text-xs font-mono text-gray-500 space-y-1">
                    <p>Event ID: {eventData.id}</p>
                    <p>Name: {eventData.name}</p>
                    <p>Has image field: {eventData.image ? "Yes" : "No"}</p>
                    {eventData.image && <p>Image path: {eventData.image}</p>}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex flex-col sm:flex-row justify-between gap-4 pt-6 border-t border-gray-700">
            <button
              type="button"
              onClick={() => navigate("/organizer/events")}
              disabled={submitting}
              className="px-6 py-3 rounded-xl bg-gray-800 hover:bg-gray-700 border border-gray-700 transition-colors font-medium disabled:opacity-50"
            >
              Batal
            </button>

            <div className="flex gap-4">
              <button
                type="button"
                onClick={() => {
                  if (eventData) {
                    populateForm(eventData);
                    setImagePreview(originalImage);
                  }
                  setError("");
                  addDebugLog("Form reset to original values");
                }}
                disabled={submitting}
                className="px-6 py-3 rounded-xl bg-gray-800 hover:bg-gray-700 border border-gray-700 transition-colors font-medium disabled:opacity-50"
              >
                Reset
              </button>

              <button
                type="submit"
                disabled={submitting || success}
                className="px-8 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 transition-all font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
              >
                {submitting ? (
                  <>
                    <Loader className="animate-spin h-5 w-5 border-t-2 border-b-2 border-white" />
                    <span>Mengupdate...</span>
                  </>
                ) : (
                  <>
                    <Save size={20} />
                    <span>Update Event</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Information Panel */}
      <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-xl">
        <div className="flex items-start gap-3">
          <Info size={20} className="text-blue-400 mt-0.5" />
          <div>
            <h4 className="font-medium text-blue-300 mb-2">
              Informasi Edit Event:
            </h4>
            <div className="text-sm text-gray-400 space-y-1">
              <p>• Event ID: {id}</p>
              <p>• User ID: {user?.id || "-"}</p>
              <p>• Event Name: {eventData?.name || "-"}</p>
              <p>• Has Image: {imagePreview ? "Yes" : "No"}</p>
              <p>• Image Path: {eventData?.image || "Not found in data"}</p>
              <p>
                • Status:{" "}
                {submitting ? "Updating..." : success ? "Success!" : "Ready"}
              </p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default EditEvent;
