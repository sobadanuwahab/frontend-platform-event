import React from "react";

const TransactionsTab = () => {
  return <div>TransactionsTab</div>;
};

export default TransactionsTab;
