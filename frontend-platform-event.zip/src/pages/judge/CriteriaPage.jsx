import React from "react";

const CriteriaPage = () => {
  return <div>CriteriaPage</div>;
};

export default CriteriaPage;
