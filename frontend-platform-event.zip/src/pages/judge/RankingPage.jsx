import React from "react";

const RankingPage = () => {
  return <div>RankingPage</div>;
};

export default RankingPage;
