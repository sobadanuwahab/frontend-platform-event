import React from "react";

function VotingList() {
  return <div>VotingList</div>;
}

export default VotingList;
