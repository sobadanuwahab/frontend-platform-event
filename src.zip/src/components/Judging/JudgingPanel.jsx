import React from "react";

function JudgingPanel() {
  return <div>JudgingPanel</div>;
}

export default JudgingPanel;
