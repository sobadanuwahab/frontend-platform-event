import React from "react";

function TicketCard() {
  return <div>TicketCard</div>;
}

export default TicketCard;
