import React from "react";

const EditParticipants = () => {
  return <div>EditParticipants</div>;
};

export default EditParticipants;
