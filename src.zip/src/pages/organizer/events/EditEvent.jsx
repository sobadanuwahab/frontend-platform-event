import React from "react";

const EditEvent = () => {
  return <div>EditEvent</div>;
};

export default EditEvent;
