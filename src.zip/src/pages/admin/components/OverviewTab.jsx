import React from "react";

const OverviewTab = () => {
  return <div>OverviewTab</div>;
};

export default OverviewTab;
