import React from "react";

const HistoryOrder = () => {
  return <div>HistoryOrder</div>;
};

export default HistoryOrder;
