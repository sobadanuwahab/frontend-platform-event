import React from "react";

const ParticipantsTab = () => {
  return <div>ParticipantsTab</div>;
};

export default ParticipantsTab;
